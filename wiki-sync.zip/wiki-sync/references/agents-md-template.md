# AGENTS.md
> Shared context for all AI coding assistants — Claude Code, Codex, Cursor, Gemini CLI, etc.
> This file is symlinked as CLAUDE.md. One source of truth.

---

## MANDATORY: How Every AI Session Must Work

These rules exist so that switching between Claude, Codex, Cursor, or any other tool mid-feature
causes zero context loss. The **Lark Wiki** is the source of truth for all plans and progress.

### Lark Wiki — Source of Truth

All project documentation lives in the **Lark Wiki** under `{{SPACE_NAME}} > {{PARENT_PATH}} > {{PROJECT_NAME}}`.
Use the `lark-wiki` skill (via `lark-cli`) to read and write wiki pages. Do NOT maintain separate
local markdown files for plans or progress — the wiki is canonical.

**Wiki structure:**
```
{{PROJECT_NAME}}
├── {{PROJECT_NAME}} — Overview
├── {{PROJECT_NAME}} — References/     (stable reference docs)
│    {{REFERENCE_PAGES_TREE}}
└── {{PROJECT_NAME}} — Updates/        (active feature work)
     {{FEATURE_PAGES_TREE}}
```

**Wiki page tokens (for lark-cli):**

| Page | obj_token |
|---|---|
| References (parent) | `{{REFERENCES_OBJ_TOKEN}}` |
| Updates (parent) | `{{UPDATES_OBJ_TOKEN}}` |
{{TOKEN_TABLE_ROWS}}

**Wiki space ID:** `{{SPACE_ID}}`
**Project node token:** `{{PROJECT_NODE_TOKEN}}`

### How to read/write wiki pages

```bash
# Read a page
lark-cli docs +fetch --api-version v2 --doc <obj_token> --doc-format markdown

# Overwrite a page
lark-cli docs +update --api-version v2 --doc <obj_token> --command overwrite --doc-format markdown --content @path/to/file.md

# Append to a page
lark-cli docs +update --api-version v2 --doc <obj_token> --command append --doc-format markdown --content "content"

# Create a new sub-page
lark-cli wiki +node-create --space-id {{SPACE_ID}} --parent-node-token <PARENT_NODE> --title "Title"
```

### At the START of every session
1. Fetch the **Updates** page for the active feature from wiki
2. Read its **Current State** — this is where the last session left off
3. If the request doesn't match any existing feature, ask before creating code

### During a session
- Architecture decisions go to the feature's **Plan** page (Key Decisions table)
- Blockers go to the feature's **Updates** page immediately

### At the END of every session (before stopping)
1. Overwrite the **Updates** page with a fresh snapshot:
   - What is working
   - What is in progress (file + function level)
   - What is not started
   - Exact next action
   - Append a progress log entry (date, tool, what you did)
2. Push via `lark-cli docs +update`

**This is not optional.** Treat updating the wiki as the last action in every session.

### When starting a brand-new feature
1. Create a folder under `{{PROJECT_NAME}} — Updates` with **Plan** and **Updates** sub-pages
2. Fill in the Plan before writing code
3. Add the new tokens to the table above

---

{{ADDITIONAL_SECTIONS}}
