---
name: wiki-sync
description: "Set up and maintain a Lark Wiki-backed project documentation system for any repo. Use when: (1) initializing a new repo with AGENTS.md + Lark Wiki structure, (2) syncing feature plans/updates to wiki at session start or end, (3) creating new feature folders in the wiki, (4) pushing reference docs to wiki. Triggers on: 'set up wiki sync', 'init agents.md', 'sync to wiki', 'push updates to wiki', 'create feature in wiki', or any request to manage project docs in Lark Wiki."
---

# Wiki Sync

Portable project documentation system that uses Lark Wiki as the single source of truth for plans, progress, and reference docs. Any AI agent (Claude, Codex, Cursor, Gemini) can read/write project state through `lark-cli` — no local markdown files to go stale.

## Prerequisites

- `lark-cli` installed and authenticated (`lark-cli config init`, `lark-cli auth login`)
- The `lark-wiki` skill available (for wiki node creation)
- A Lark Wiki space where the project lives

## Workflows

### 1. Initialize a New Repo (`init`)

Run this once per repo to set up the full system.

**Step 1 — Discover the wiki space and project node:**

```bash
# List available wiki spaces
lark-cli wiki spaces list --format json

# List top-level nodes in the space
lark-cli wiki nodes list --params '{"space_id":"<SPACE_ID>"}' --format json

# Find or create the project node
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <PARENT_NODE> --title "<Project Name>"
```

Ask the user which space and parent node to use. If the project node already exists, use it.

**Step 2 — Create the wiki structure under the project node:**

```
<Project Name>
├── <Project> — Overview
├── <Project> — References/        (stable reference docs)
└── <Project> — Updates/           (active feature work)
```

Create each node:
```bash
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <PROJECT_NODE> --title "<Project> — References"
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <PROJECT_NODE> --title "<Project> — Updates"
```

Record the `node_token` and `obj_token` from each response.

**Step 3 — Push any existing reference docs** (UI guide, architecture vision, contracts, etc.):

```bash
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <REFERENCES_NODE> --title "Doc Title"
# Note the obj_token from the response
lark-cli docs +update --api-version v2 --doc <OBJ_TOKEN> --command overwrite --doc-format markdown --content @path/to/doc.md
```

Content files must use relative paths with v2 API. Copy to `.context/` if the source is outside the repo.

**Step 4 — Generate AGENTS.md** at the repo root with the wiki structure and tokens. Use the template in `references/agents-md-template.md`, filling in all discovered values (space ID, node tokens, obj_tokens, project name, wiki tree).

**Step 5 — Symlink:** If the repo uses Claude Code, run `ln -sf AGENTS.md CLAUDE.md`.

### 2. Create a New Feature (`new-feature`)

When starting work on a new feature:

```bash
# Create feature folder under Updates
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <UPDATES_NODE> --title "<Feature Name>"

# Create Plan sub-page
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <FEATURE_NODE> --title "Plan"

# Create Updates sub-page
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <FEATURE_NODE> --title "Updates"
```

Push initial content to both pages using the templates:

- **Plan:** `# <Feature> — Plan\n\n## Overview\n\n## Phases\n\n## Key Decisions\n\n| Decision | Why |\n|---|---|`
- **Updates:** `# <Feature> — Updates\n\n## Current State\n\n**What is working:**\n\n**What is in progress:**\n\n**What is not started:**\n\n**Blockers:**\n\n**Next action:**\n\n## Progress Log`

Then add the new page tokens to the AGENTS.md token table.

### 3. Session Start (`sync-down`)

At the beginning of every AI session:

1. Read AGENTS.md to get the token table
2. Identify the active feature from the user's request
3. Fetch its Updates page:

```bash
lark-cli docs +fetch --api-version v2 --doc <UPDATES_OBJ_TOKEN> --doc-format markdown
```

4. Parse the Current State section — this is where the last session left off

### 4. Session End (`sync-up`)

At the end of every AI session:

1. Build a fresh snapshot of current state (what's working, in progress, not started, blockers, next action)
2. Append a progress log entry (date, tool name, summary of what was done)
3. Write to a local temp file in `.context/`
4. Push to wiki:

```bash
lark-cli docs +update --api-version v2 --doc <UPDATES_OBJ_TOKEN> --command overwrite --doc-format markdown --content @.context/updates-snapshot.md
```

5. If key decisions were made during the session, also update the Plan page:

```bash
lark-cli docs +update --api-version v2 --doc <PLAN_OBJ_TOKEN> --command overwrite --doc-format markdown --content @.context/plan-snapshot.md
```

### 5. Push Reference Doc (`push-ref`)

When a reference doc needs to be synced to wiki:

```bash
# If page already exists, overwrite
lark-cli docs +update --api-version v2 --doc <REF_OBJ_TOKEN> --command overwrite --doc-format markdown --content @docs/my-reference.md

# If page doesn't exist, create it first
lark-cli wiki +node-create --space-id <SPACE_ID> --parent-node-token <REFERENCES_NODE> --title "Doc Title"
# Then push content using the new obj_token
```

Add the new token to AGENTS.md.

## Rules

- **Wiki is canonical.** Never maintain parallel local docs for plans/progress.
- **AGENTS.md stays local.** It's the bootstrap file — contains the token table and workflow, not the actual content.
- **Always use `--api-version v2`** for `docs +fetch` and `docs +update`. v1 silently fails on docx pages.
- **Always use `--doc-format markdown`** for both read and write.
- **Content via `@file` must use relative paths** with v2 API. Copy to `.context/` if needed.
- **Token table in AGENTS.md must stay current.** Add new tokens immediately after creating pages.
- **Progress log entries are append-only.** Never delete past entries. Each session adds one entry.
- **Current State is overwrite-only.** Always replace with a fresh snapshot — never append.
- **Plan pages are stable.** Update only when phases change, scope shifts, or key decisions are made. Not every session.
